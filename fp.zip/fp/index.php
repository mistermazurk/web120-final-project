<?php include 'includes/header.php';?>   
<!-- START LEFT COL -->
 <h1 class="pageID">Weirdo Comics for Weirdo People</h1>
<section>
<h2>About:</h2>

 <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
    <img src="images/pg.jpg" class="tablet" alt="" />
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder tex   t goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
    
    <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
    <img src="images/pg.jpg" class="tablet" alt="" />
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder tex   t goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>

<img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
    <img src="images/pg.jpg" class="tablet" alt="" />
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder tex   t goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
    </section>
<!-- END LEFT COL -->

<!-- START RIGHT COL -->
<aside>
    <h2>Featured:</h2>
    
     <img src="images/pd.jpg" class="desktop" alt="" />
 <img src="images/pd.jpg" class="phone" alt="" />
    <img src="images/pd.jpg" class="tablet" alt="" />
    <br>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
    
     <img src="images/god_monster.jpg" class="desktop" alt="" />
 <img src="images/god_monster.jpg" class="phone" alt="" />
    <img src="images/god_monster.jpg" class="tablet" alt="" />
    <br>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
  <img src="images/cat_liz.jpg" class="desktop" alt="" />
 <img src="images/cat_liz.jpg" class="phone" alt="" />
    <img src="images/cat_liz.jpg" class="tablet" alt="" />
    <br>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
</aside>
<!-- END RIGHT COL -->
<?php include 'includes/footer.php';?>
