<?php include 'includes/header.php';?>   
          <script src='https://www.google.com/recaptcha/api.js?hl=en'></script>
<?php 
  foreach ($_POST as $key => $value) {
    echo '<p><strong>' . $key.':</strong> '.$value.'</p>';
  }
?>
<!-- START LEFT COL -->
<h1 class="pageID">Contact Page</h1>
<section>
 <h2>Contact Us</h2>

<!-- MAKE SURE YOU GET YOUR (3) IMAGES SAVED INTO YOUR IMAGES FOLDER -->
 <img src="images/radical.jpg" class="desktop" alt="" />
 <img src="images/radical.jpg" class="phone" alt="" />
     <img src="images/radical.jpg" class="tablet" alt="" />

</section>
<!-- END LEFT COL -->

<!-- START RIGHT COL -->
<aside>
    <h3>We Want to Hear From You!</h3>
<p>Please fill out this form and we will get back to you as soon as possible.</p>

  <form action="/web120/fp/action_page.php" method="post">
      <div>
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" placeholder="Your name">
<br>
    <label for="lname">Email:</label>
    <input type="text" id="email" name="email" placeholder="Your E-mail">
  
<br>
    <label for="msg"></label>
    <textarea id="msg" name="msg" placeholder="Tell us something:" style="height:500px"></textarea>
<br>
          <div class="g-recaptcha" data-sitekey="6LcplZkUAAAAAOgA02J7dFNo-XM0xcoMaWA6Wb0S"></div>
    <input type="submit" value="Submit">

          </div>
  </form>


</aside>
<!-- END RIGHT COL -->
<?php include 'includes/footer.php';?>

