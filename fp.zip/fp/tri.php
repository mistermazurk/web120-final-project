<?php include 'includes/header.php';?>   

<!-- START LEFT COL -->

 <h1 class="pageID" id="myTopnav">Tri-County</h1>
<section>
   
<h3>The Story So Far:</h3>
      <div class="flex-container">

<img src="images/tricnty.jpg" class="desktop" alt="" />
 <img src="images/tricnty.jpg" class="phone" alt="" />
 <img src="images/tricnty.jpg" class="tablet" alt="" />
<p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>

          <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
 <img src="images/pg.jpg" class="tablet" alt="" />
<p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>\

          
          <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
 <img src="images/pg.jpg" class="tablet" alt="" />
<p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
          
          <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
 <img src="images/pg.jpg" class="tablet" alt="" />
<p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
   </div>       
</section>
<!-- START RIGHT COL -->

<aside> 

    <h2>Characters:</h2>
<div class="flex-container">
     <img src="images/cat.jpg" class="desktop" alt="" />
 <img src="images/cat.jpg" class="phone" alt="" />
    <img src="images/cat.jpg" class="tablet" alt="" />
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
    <br>
         <img src="images/lizard.jpg" class="desktop" alt="" />
 <img src="images/lizard.jpg" class="phone" alt="" />
    <img src="images/lizard.jpg" class="tablet" alt="" />
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <br>
         <img src="images/harry.jpg" class="desktop" alt="" />
 <img src="images/harry.jpg" class="phone" alt="" />
    <img src="images/harry.jpg" class="tablet" alt="" />
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
    </div>
</aside>
<!-- END RIGHT COL -->

<?php include 'includes/footer.php';?>