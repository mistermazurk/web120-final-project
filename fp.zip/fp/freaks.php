<?php include 'includes/header.php';?>   

<!-- START LEFT COL -->

 <h1 class="pageID" id="myTopnav">The Family of Serious Freaks</h1>

<section>
   
<h2>The Story So Far:</h2>
      <div class="flex-container">

<img src="images/winn.jpg" class="desktop" alt="" />
 <img src="images/winn.jpg" class="phone" alt="" />
 <img src="images/winn.jpg" class="tablet" alt="" />
<p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
          
          <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
 <img src="images/pg.jpg" class="tablet" alt="" />
<p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
          
          <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
 <img src="images/pg.jpg" class="tablet" alt="" />
<p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
          
          <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
 <img src="images/pg.jpg" class="tablet" alt="" />
<p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
   </div>       
</section>
<!-- START RIGHT COL -->

<aside> 
    
    <h2>Characters:</h2>
<div class="flex-container">
     <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
    <img src="images/pg.jpg" class="tablet" alt="" />
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
    <br>
         <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
    <img src="images/pg.jpg" class="tablet" alt="" />
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
 <br>
         <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
    <img src="images/pg.jpg" class="tablet" alt="" />
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
    
             <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
    <img src="images/pg.jpg" class="tablet" alt="" />
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
             <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
    <img src="images/pg.jpg" class="tablet" alt="" />
 <p>Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now Lorem Ipsum place holder text goes here for now. Lorem Ipsum place holder text goes here for now</p>
    </div>
    </div>
    
    </div>
    
    
</aside>
<!-- END RIGHT COL -->

<?php include 'includes/footer.php';?>
