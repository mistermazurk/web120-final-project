<?php include 'includes/header.php';?>   
<!-- START LEFT COL -->
 <h1 class="pageID"><b>Thanks!</b></h1>
<section>


 <img src="images/pg.jpg" class="desktop" alt="" />
 <img src="images/pg.jpg" class="phone" alt="" />
    <img src="images/pg.jpg" class="tablet" alt="" />

</section>
<!-- END LEFT COL -->


<!-- END RIGHT COL -->
<?php include 'includes/footer.php';?>